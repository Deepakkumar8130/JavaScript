
document.getElementById("start").addEventListener("click", startEffect);
document.getElementById("stop").addEventListener("click", stopEffect);