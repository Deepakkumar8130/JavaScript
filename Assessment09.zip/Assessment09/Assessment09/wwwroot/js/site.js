﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.








var interval = null;
var total = 0;

function totalValue() {
    total = Number(hour.value) * 360;
    total += Number(minute.value) * 60;
    total += Number(second.value);
}

function formatTime(value) {
    return value.toString().padStart(2, '0');
}


function Timer(){
    totalValue();
    total--;

    if (total >= 0) {
        var hr = Math.floor(total / 3600);
        var mt = Math.floor((total / 60) - (hr*60));
        var sc = total - ((hr * 3600) + (mt * 60));

        digital.innerHTML = formatTime(hr) + ':' + formatTime(mt) + ':' + formatTime(sc);
        hour.value = hr;
        minute.value = mt;
        second.value = sc;
    }
    else {
        clearInterval(interval)
        disp.innerText = "Time Over !!";
        document.getElementById("timerForm").style.display = "block"; 
    }
};

function start() {
    clearInterval(interval)
    document.getElementById("timerForm").style.display = "none"; 
    interval = setInterval(Timer, 1000);

    disp.innerText = "Timer Started";
};

function stop() {
    disp.innerText = "Timer Stoped";
    clearInterval(interval)
}

function reset() {
    disp.innerText = "Timer";
    document.getElementById("timerForm").style.display = "block"; 
    clearInterval(interval);
    hour.value = 0;
    minute.value = 0;
    second.value = 0;
    digital.innerHTML = formatTime(0) + ':' + formatTime(0) + ':' + formatTime(0);
}