$(document).ready(function () {
    document.getElementById("suggestion").addEventListener("click", suggestion);
    document.getElementById("showPassword").addEventListener("click", togglePassword);
})